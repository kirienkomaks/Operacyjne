Należy uruchomić najpierw program serwer, następnie program client. Po uruchomieniu obu programów powinnien się przesłać plik "toSend.txt" i zapisac jako "oebrany.txt"
